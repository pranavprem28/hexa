import "./globals.css"
import Navbar from "./components/Navbar"
import Footer from "./components/Footer"
import { CartProvider } from "./context/CartContext"

export const metadata = {
  title: "DevStore",
  description: "Modern Ecommerce App"
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className="bg-gray-50 text-gray-900">
        <CartProvider>
          <Navbar />
          <main className="min-h-screen max-w-7xl mx-auto px-6 py-10">
            {children}
          </main>
          <Footer />
        </CartProvider>
      </body>
    </html>
  )
}