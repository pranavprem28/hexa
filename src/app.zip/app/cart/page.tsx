"use client"
import { useCart } from "../context/CartContext"

export default function CartPage() {
  const { cart, removeFromCart } = useCart()

  return (
    <div>
      <h2 className="text-3xl font-bold mb-6">Your Cart</h2>

      {cart.length === 0 && <p>Your cart is empty.</p>}

      {cart.map((item: any) => (
        <div
          key={item.id}
          className="flex justify-between bg-white p-4 rounded shadow mb-4"
        >
          <span>{item.title}</span>
          <button
            onClick={() => removeFromCart(item.id)}
            className="text-red-500"
          >
            Remove
          </button>
        </div>
      ))}
    </div>
  )
}