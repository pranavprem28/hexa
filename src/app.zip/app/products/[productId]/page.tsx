import { ProductsService } from "../../services/products-service"
import Image from "next/image"

export default async function ProductDetail({ params }: any) {
  console.log("PARAMS:", params)

  const id = Number(params.id) 

  if (isNaN(id)) {
    throw new Error("Invalid product ID")
  }

  const product = await ProductsService.getProductById(id)

  return (
    <div className="grid md:grid-cols-2 gap-10">
      <Image
        src={product.image}
        alt={product.title}
        width={400}
        height={400}
      />
      <div>
        <h1 className="text-3xl font-bold">{product.title}</h1>
        <p className="text-gray-600 mt-4">{product.description}</p>
        <p className="text-blue-600 text-2xl mt-4 font-bold">
          ${product.price}
        </p>
      </div>
    </div>
  )
}