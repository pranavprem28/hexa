import { ProductsService } from "../services/products-service"
import ProductList from "../components/ProductList"

export const revalidate = 60

export default async function Products() {
  const products = await ProductsService.getProducts()

  return (
    <>
      <h2 className="text-3xl font-bold mb-8">All Products</h2>
      <ProductList products={products} />
    </>
  )
}